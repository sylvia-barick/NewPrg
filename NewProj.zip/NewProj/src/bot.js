<script>
    window.embeddedChatbotConfig = {
    chatbotId: "010bm1cmIXwvDP1gFdH-i",
    domain: "www.chatbase.co"
    }
    </script>
    <script
    src="https://www.chatbase.co/embed.min.js"
    chatbotId="010bm1cmIXwvDP1gFdH-i"
    domain="www.chatbase.co"
    defer>
    </script>